// import Model from '../ember-data/model';
// import attr from '../ember-data-latest/attr';

// export default Model.extend({
//   receta: attr(),
//   ingredientes: attr(),
//   procedimientos: attr(),
//   pais: attr(),
//   numero: attr()
// });

// App.Marcapagina = DS.Model.extend({
//     nombre: DS.attr('string'),
//     url: DS.attr('string')
// });
