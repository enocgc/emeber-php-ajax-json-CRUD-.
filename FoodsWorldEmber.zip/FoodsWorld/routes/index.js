// import Ember from 'ember';
// var comidas=[];
// function getDatosIndex(datos){
// 	comidas=datos;
// export default Ember.Route.extend({
// model() {

//       comidas =[{receta:'qwe', ingredientes:'qwe', procedimientos:'werwe', pais:'costa rica',numero:1}];
//   		// getComidas();
//   		 return comidas;
//   } 

// });
// }

// export default Ember.Route.extend({
// model() {

//       comidas =[{receta:'qwe', ingredientes:'qwe', procedimientos:'werwe', pais:'costa rica',numero:1}];
//   		// getComidas();
//   		 return comidas;
//   } 

// });